//Name: Manjot, Thuvaragan, Yatharth
//Date: May 18, 2023
//Purpose: Grid For The Game

package com.hbs.gamesnake;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;

public class SnakeAdapter extends BaseAdapter {

    private Context context;
    private int[] colors;

    public SnakeAdapter(Context fed_context, int[] fed_colors) {
        context = fed_context;
        colors = fed_colors;
    }

    @Override
    public int getCount() {
        return colors.length;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        FrameLayout frameLayout;
        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(context);
            frameLayout = (FrameLayout) inflater.inflate(R.layout.grid_cell_layout, parent, false);
        }

        else {
            frameLayout = (FrameLayout) convertView;
        }

        // Set the background color of the frame layout
        frameLayout.setBackgroundColor(colors[position % colors.length]);

        return frameLayout;
    }
}