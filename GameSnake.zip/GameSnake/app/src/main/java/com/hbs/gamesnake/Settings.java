//Name: Manjot, Thuvaragan, Yatharth
//Date: May 18, 2023
//Purpose: Settings Screen

package com.hbs.gamesnake;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Switch;
import com.google.android.material.slider.Slider;

import yuku.ambilwarna.AmbilWarnaDialog;

public class Settings extends AppCompatActivity {
    public Button colorButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // if back button is clicked, go back to the previous page
        ImageButton back = (ImageButton) findViewById(R.id.backButton);

        back.setOnClickListener(v -> {
            this.finish();
        });

        // if slider is changed, change the volume
        Slider volumeSlider = (Slider) findViewById(R.id.volume);
        volumeSlider.setValue(MainActivity.volumeValue);
        volumeSlider.addOnChangeListener( (slider, value, fromUser) -> {
            MainActivity.music.setVolume(value, value);
            MainActivity.volumeValue = value;
        });

        // if switch is toggled, change the soundEffects variable
        Switch sfxToggle = (Switch) findViewById(R.id.sfxToggle);
        sfxToggle.setChecked(MainActivity.soundEffects);
        sfxToggle.setOnCheckedChangeListener((v, isChecked) -> {
            MainActivity.soundEffects = isChecked;
        });

        // show color picker
        Button colorPicker = (Button) findViewById(R.id.pick_color);
        colorButton = (Button) findViewById(R.id.color);
        colorButton.setBackgroundColor(MainActivity.color);
        colorPicker.setOnClickListener(v -> {
            openColorPicker();
        });
    }

    public void openColorPicker() {
        // create a ambil warna dialog which is the colour picker
        AmbilWarnaDialog ambilWarnaDialog = new AmbilWarnaDialog(this, MainActivity.color, new AmbilWarnaDialog.OnAmbilWarnaListener() {
            @Override
            public void onCancel(AmbilWarnaDialog dialog) {

            }

            @Override
            public void onOk(AmbilWarnaDialog dialog, int color) {
                MainActivity.color = color;
                colorButton.setBackgroundColor(color);
            }
        });
        ambilWarnaDialog.show();
    }
}