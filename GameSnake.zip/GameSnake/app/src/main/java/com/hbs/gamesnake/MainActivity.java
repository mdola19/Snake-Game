//Name: Manjot, Thuvaragan, Yatharth
//Date: May 18, 2023
//Purpose: Main Game Screen

package com.hbs.gamesnake;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.atomic.AtomicBoolean;


public class MainActivity extends AppCompatActivity {
    static boolean started = false;

    static MediaPlayer music;
    static float volumeValue = 1.0f;
    static boolean soundEffects = true;

    static int color = Color.GREEN;

    MediaPlayer pointEarned, gameOver;

    // Declaring all the screen elements
    private GridView playGrid;
    private Button up;
    private Button right;
    private Button left;
    private Button down;
    private Button reset;
    private Button exit;
    private Button pause;
    private Button settings;
    private TextView score;

    int points = 0;
    // Declaring Game Variables
    Timer snakeTimer;
    TimerTask task;
    ArrayList<Integer> snakeCells = new ArrayList<Integer>();
    int snakeHeading = 2; // 1 = up, 2 = down, 3 = right, 4 = left
    int[] colors = new int[400];
    int appleIndex = (int) (Math.random() * 300);

    // Defining Color Variables
    int r = Color.RED;
    int g = Color.GREEN;
    int e = Color.BLACK;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Casting Screen Elements
        up = (Button)findViewById(R.id.upBtn);
        down = (Button)findViewById(R.id.downBtn);
        left = (Button)findViewById(R.id.leftBtn);
        right = (Button)findViewById(R.id.rightBtn);
        reset = (Button)findViewById(R.id.resetBtn);
        exit = (Button)findViewById(R.id.exitBtn);
        pause = (Button)findViewById(R.id.pauseBtn);
        settings = (Button)findViewById(R.id.settingsBtn);
        playGrid = (GridView)findViewById(R.id.playingGrid);
        score = (TextView)findViewById(R.id.scoreText);

        AtomicBoolean paused = new AtomicBoolean(false);

        // Initial setup of screen
        for(int i = 0; i < colors.length - 1; i++) {
            colors[i] = e;
        }

        snakeCells.add(0);
        snakeCells.add(1);
        snakeCells.add(2);
        updateSnake();

        colors[appleIndex] = r;

        playGrid.setAdapter(new SnakeAdapter(this, colors));
        pointEarned = MediaPlayer.create(this, R.raw.pointearned);
        gameOver = MediaPlayer.create(this, R.raw.gameover);

        if(started == false) {
            startActivity(new Intent(MainActivity.this, SplashScreen.class));
            finish();
        } else {
            startTimer();
        }



        right.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                snakeHeading = 3;
            }
        });

        left.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                snakeHeading = 4;
            }
        });

        up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                snakeHeading = 1;
            }
        });

        down.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                snakeHeading = 2;
            }
        });


        pause.setOnClickListener(v -> {
            if(!paused.get()) {
                snakeTimer.cancel();
                pause.setText("Resume");
                paused.set(true);
            } else {
                startTimer();
                pause.setText("Pause");
                paused.set(false);
            }
        });

        exit.setOnClickListener(v -> {
            snakeTimer.cancel();
            task.cancel();
            Intent intent = new Intent(MainActivity.this, MainMenu.class);
            startActivity(intent);
        });

        settings.setOnClickListener(v -> {
            snakeTimer.cancel();
            task.cancel();
            paused.set(true);
            pause.setText("Resume");
            Intent intent = new Intent(MainActivity.this, Settings.class);
            startActivity(intent);

        });

        reset.setOnClickListener(v -> {
            snakeTimer.cancel();
            task.cancel();
            snakeCells = new ArrayList<Integer>();
            points = 0;
            score.setText(Integer.toString(points));
            color = Color.GREEN;
            for(int i = 0; i < colors.length - 1; i++) {
                colors[i] = e;
            }


            snakeCells.add(0);
            snakeCells.add(1);
            snakeCells.add(2);
            updateSnake();
            appleIndex = (int) (Math.random()*300);

            colors[appleIndex] = r;
            increment = 0;
            counter = 2;

            snakeHeading = 2;


            startTimer();


        });


    }

    int counter = 2;
    int increment = 0;

    // Every time timer ticks, snake is moved in its current direction
    private void startTimer() {
        snakeTimer = new Timer();
        task = new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        System.out.println(snakeDeaths());

                        switch (snakeHeading) {
                            case 1:
                                increment = -20;
                                break;
                            case 2:
                                increment = 20;
                                break;
                            case 3:
                                increment = 1;
                                break;
                            case 4:
                                increment = -1;
                                break;
                        }

                        if (eatApple()) {
                            snakeCells.add(0, snakeCells.get(0) - increment);
                        }

                        snakeCells.add(counter + increment);
                        colors[snakeCells.get(0)] = e;
                        snakeCells.remove(0);
                        updateSnake();
                        playGrid.setAdapter(new SnakeAdapter(MainActivity.this, colors));
                        counter += increment;

                        if (snakeDeaths()) {
                            if(soundEffects) gameOver.start();
                            snakeTimer.cancel();
                            task.cancel();
                            Intent intent = new Intent(MainActivity.this, GameOver.class);
                            startActivity(intent);
                        }
                    }
                });
            }
        };

        snakeTimer.scheduleAtFixedRate(task, 0, 150);
    }

    // Used to update the snakeCells array every time it is moved
    private void updateSnake() {
        for(int i = 0; i < snakeCells.size() - 1; i++) {
            colors[snakeCells.get(i)] = color;
        }
    }

    // Deals with eaten apples
    private boolean eatApple() {
        for(int i = 0; i < snakeCells.size() - 1; i++) {
            if(snakeCells.get(i) == appleIndex) {
                appleIndex = (int) (Math.random()*300);
                colors[appleIndex] = Color.RED;
                points += 1;
                score.setText(Integer.toString(points));
                if(soundEffects) {
                    pointEarned.start();
                }
                return true;
            }
        }

        return false;
    }

    // Deals with snake deaths
    private boolean snakeDeaths() {
        if(snakeHeading == 1 && counter < 0) {
            return true;
        }

        else if(snakeHeading == 2 && counter >= 300) {
            return true;
        }

        else if(snakeHeading == 3 && counter%20 == 0) {
            return true;
        }

        else if(snakeHeading == 4 && counter%20 == 19) {
            return true;
        }

        else {
            return false;
        }
    }
}