//Name: Manjot, Thuvaragan, Yatharth
//Date: May 18, 2023
//Purpose: Game Over Screen

package com.hbs.gamesnake;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class GameOver extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_over);

        Button retry = (Button) findViewById(R.id.retry);
        retry.setOnClickListener(v -> {
            Intent intent = new Intent(GameOver.this, MainActivity.class);
            startActivity(intent);
        });

        Button mainmenu = (Button) findViewById(R.id.mainmenu);
        mainmenu.setOnClickListener(v -> {
            Intent intent = new Intent(GameOver.this, MainMenu.class);
            startActivity(intent);
        });
    }
}