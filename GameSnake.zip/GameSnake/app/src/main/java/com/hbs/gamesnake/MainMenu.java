//Name: Manjot, Thuvaragan, Yatharth
//Date: May 18, 2023
//Purpose: Main Menu Screen

package com.hbs.gamesnake;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.widget.Button;
public class MainMenu extends AppCompatActivity {
    Button start, instructions, settings;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);
        if(MainActivity.started == false) {
            MainActivity.music = MediaPlayer.create(this, R.raw.background_music);
            MainActivity.music.start();
            MainActivity.music.setLooping(true);
        }
        MainActivity.started = true;


        start = (Button) findViewById(R.id.startButton);
        start.setOnClickListener(v -> {
            Intent intent = new Intent(MainMenu.this, MainActivity.class);
            startActivity(intent);
        });
        instructions = (Button) findViewById(R.id.instructionButton);
        instructions.setOnClickListener(v -> {
            Intent intent = new Intent(MainMenu.this, Instructions.class);
            startActivity(intent);
        });

        settings = (Button) findViewById(R.id.settingsButton);
        settings.setOnClickListener(v -> {
            Intent intent = new Intent(MainMenu.this, Settings.class);
            startActivity(intent);
        });

    }


}
