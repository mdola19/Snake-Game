//Name: Manjot, Thuvaragan, Yatharth
//Date: May 18, 2023
//Purpose: Instruction Screen

package com.hbs.gamesnake;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.widget.ImageButton;

public class Instructions extends AppCompatActivity {
    ImageButton instructionsReturn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_instructions);

        instructionsReturn = (ImageButton) findViewById(R.id.instructionsBackButton);
        instructionsReturn.setOnClickListener(v -> {
            Intent intent = new Intent(com.hbs.gamesnake.Instructions.this, MainMenu.class);
            startActivity(intent);
        });
    }
}